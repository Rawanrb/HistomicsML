# HistomicsML
An interactive machine learning framework for large histopathology images.

**Paper**: [M Nalisnik et al, "Interactive phenotyping of large-scale histology imaging data with HistomicsML"](http://www.biorxiv.org/content/early/2017/05/19/140236)

Documentation available on http://histomicsml.readthedocs.io/en/latest/
