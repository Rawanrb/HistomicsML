<?php

	# !!!!!
	# !!!!! The one and ONLY place the active learning server is defined
	# !!!!!
	$port = 10000;
	$host = "localhost";

	
	#
	#	IIP server 
	#
	$IIPServer = "http://170.140.61.157/fcgi-bin/iipsrv.fcgi?";			
?>

